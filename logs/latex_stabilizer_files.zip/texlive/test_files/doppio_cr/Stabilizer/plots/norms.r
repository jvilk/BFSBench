library(ggplot2)
library(grid)

N = 5000000

group <- c(rep('a', N), rep('b', N))
x <- c(rnorm(N, mean=90.3, sd=1), rnorm(N, mean=92.8, sd=1.3))

dat <- data.frame(group=group, x=x)

p <- qplot(x, data=dat, stat='density', 
	color=I('black'), 
	size=I(0.2), 
	fill=group,
	geom='density', 
	xlab='Time (s)',
	ylab='Probability Density',
	alpha=I(5/6)
) +
	scale_fill_brewer(palette='YlGn') + guides(fill=FALSE) +
	theme_bw(12, 'Palatino') + 
	theme(
		plot.title = element_text(size=12, face='bold'),
		plot.margin = unit(c(0, 0, 0, 0), 'in'),
		panel.border = element_rect(colour='gray'),
		axis.title.y = element_text(size=11)
	)

ggsave(filename='../slides/norms.pdf', width=7, height=4)

p2 <- qplot(x, data=dat, stat='density', 
	fill=group,
	color=group,
	geom='density',
	xlab='Time (s)',
	ylab='Probability Density',
	alpha=I(3/4)
) +
scale_fill_brewer(palette='YlGn') + 
scale_color_manual(values=c(0, 0)) +
guides(fill=FALSE) +
theme_bw(12, 'Palatino') + 
theme(
	axis.line = element_blank(),
	axis.ticks = element_blank(),
	axis.text.x = element_blank(),
	axis.text.y = element_blank(),
	axis.title.x = element_blank(),
	axis.title.y = element_blank(),
	panel.background = element_blank(),
	panel.border = element_blank(),
	panel.grid.major = element_blank(),
	panel.grid.minor = element_blank(),
	plot.background = element_blank(),
	legend.position = 'none'
)

ggsave(filename='../slides/norms_blank.pdf', width=7, height=4)
