import math
import random

def sample_gen():
	x = random.random()
	return x**3/math.cos(x)

for n in [1, 5, 10, 15, 20, 25, 30, 35, 40]:
	samples = []
	
	for i in range(0, 100000):
		s = 0
		for j in range(0, n):
			s += sample_gen()
		samples.append(s/n)
	
	samples.sort()
	
	bins = {}
	bin = samples[0]
	bin_width = .05
	
	for s in samples:
		if bin not in bins:
			bins[bin] = 0
			
		while(s > bin + bin_width/2):
			bin += bin_width
			if bin not in bins:
				bins[bin] = 0
		
		bins[bin] += 1
	
	keys = bins.keys()
	keys.sort()
	
	for x in keys:
		print x, ",", bins[x]